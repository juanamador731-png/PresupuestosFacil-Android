# Presupuestos Fácil — Android

Proyecto Android base para publicar Presupuestos Fácil en Google Play.

- Package ID: com.presupuestosfacil.app
- Version: 1.0
- Target SDK: 35
- Carga la versión publicada en GitHub Pages.

Para generar el AAB, abre el proyecto en Android Studio y ejecuta:
./gradlew bundleRelease

Antes de producción hay que configurar firma, política de privacidad y el sistema de compras de Google Play para la suscripción de 4,99 €/mes.
